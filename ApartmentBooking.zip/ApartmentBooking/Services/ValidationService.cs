using System;
using System.Text.RegularExpressions;

namespace ApartmentBooking.Services
{
    // A small helper that carries the result of a validation: whether it passed
    // and an error message that the GUI can show to the user if it failed.
    public class ValidationResult
    {
        public bool IsValid { get; set; }
        public string ErrorMessage { get; set; }

        public ValidationResult()
        {
            IsValid = true;
            ErrorMessage = "";
        }
    }

    // A "static class" cannot be created with "new". In Java you would get the
    // same effect with a private constructor and only static methods.
    public static class ValidationService
    {
        private static ValidationResult Ok()
        {
            ValidationResult result = new ValidationResult();
            result.IsValid = true;
            return result;
        }

        private static ValidationResult Fail(string message)
        {
            ValidationResult result = new ValidationResult();
            result.IsValid = false;
            result.ErrorMessage = message;
            return result;
        }

        // ---------- GUEST ----------
        public static ValidationResult ValidateGuest(string firstName, string lastName, string email, string phone)
        {
            // Java: firstName == null || firstName.trim().isEmpty()
            // C# has one ready method that checks null AND empty AND whitespace.
            if (string.IsNullOrWhiteSpace(firstName))
                return Fail("Krestni jmeno nesmi byt prazdne.");

            if (firstName.Trim().Length < 2 || firstName.Trim().Length > 50)
                return Fail("Krestni jmeno musi mit 2-50 znaku.");

            if (string.IsNullOrWhiteSpace(lastName))
                return Fail("Prijmeni nesmi byt prazdne.");

            if (lastName.Trim().Length < 2 || lastName.Trim().Length > 50)
                return Fail("Prijmeni musi mit 2-50 znaku.");

            if (string.IsNullOrWhiteSpace(email))
                return Fail("E-mail nesmi byt prazdny.");

            // Java: Pattern.matches(regex, email)
            // C#: Regex.IsMatch(...). The @"..." is a "verbatim" string so we don't
            // have to double the backslashes.
            if (!Regex.IsMatch(email.Trim(), @"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$"))
                return Fail("E-mail ma neplatny format (napr. jan@email.cz).");

            if (!string.IsNullOrWhiteSpace(phone))
            {
                if (!Regex.IsMatch(phone.Trim(), @"^\+?[\d\s\-]{9,15}$"))
                    return Fail("Telefonni cislo ma neplatny format.");
            }

            return Ok();
        }

        // ---------- APARTMENT ----------
        public static ValidationResult ValidateApartment(string name, string address, string priceText, string capacityText)
        {
            if (string.IsNullOrWhiteSpace(name))
                return Fail("Nazev apartmanu nesmi byt prazdny.");

            if (name.Trim().Length < 2 || name.Trim().Length > 100)
                return Fail("Nazev apartmanu musi mit 2-100 znaku.");

            if (string.IsNullOrWhiteSpace(address))
                return Fail("Adresa nesmi byt prazdna.");

            // Java: try { Integer.parseInt(text) } catch (NumberFormatException e) {...}
            // C# has int.TryParse which returns false instead of throwing.
            int price;
            string priceClean = (priceText == null) ? "" : priceText.Trim();
            if (!int.TryParse(priceClean, out price))
                return Fail("Cena za noc musi byt cele cislo.");

            if (price < 1 || price > 1000000)
                return Fail("Cena za noc musi byt v rozsahu 1-1000000 Kc.");

            int capacity;
            string capacityClean = (capacityText == null) ? "" : capacityText.Trim();
            if (!int.TryParse(capacityClean, out capacity))
                return Fail("Kapacita musi byt cele cislo.");

            if (capacity < 1 || capacity > 50)
                return Fail("Kapacita musi byt v rozsahu 1-50 osob.");

            return Ok();
        }

        // ---------- RESERVATION ----------
        public static ValidationResult ValidateReservation(int guestId, int apartmentId, DateTime checkIn, DateTime checkOut)
        {
            if (guestId <= 0)
                return Fail("Musi byt vybran platny host.");

            if (apartmentId <= 0)
                return Fail("Musi byt vybran platny apartman.");

            // .Date strips the time part so we compare whole days only.
            // Java: checkIn.toLocalDate().isBefore(LocalDate.now())
            if (checkIn.Date < DateTime.Now.Date)
                return Fail("Datum prijezdu nemuze byt v minulosti.");

            if (checkOut.Date <= checkIn.Date)
                return Fail("Datum odjezdu musi byt po datu prijezdu.");

            double nights = (checkOut.Date - checkIn.Date).TotalDays;
            if (nights > 365)
                return Fail("Rezervace nemuze byt delsi nez 365 noci.");

            return Ok();
        }
    }
}
