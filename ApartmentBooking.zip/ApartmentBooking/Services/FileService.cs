using System;
using System.Collections.Generic;
using System.IO;
using ApartmentBooking.Models;

namespace ApartmentBooking.Services
{
    // Handles all reading and writing of .txt files inside the AppData folder.
    public class FileService
    {
        private string appDataPath;
        private string guestsFile;
        private string apartmentsFile;
        private string reservationsFile;
        private string logFile;

        public FileService()
        {
            // Java on Windows: System.getenv("APPDATA"). C# has one method that
            // returns the right folder on every operating system.
            //   Windows: C:\Users\<name>\AppData\Roaming
            //   Linux:   /home/<name>/.config
            string roaming = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

            // Java: roaming + File.separator + "ApartmentBooking"
            // C#: Path.Combine picks the correct slash for the current OS.
            appDataPath = Path.Combine(roaming, "ApartmentBooking");

            // Java: new File(appDataPath).mkdirs()
            Directory.CreateDirectory(appDataPath);

            guestsFile = Path.Combine(appDataPath, "guests.txt");
            apartmentsFile = Path.Combine(appDataPath, "apartments.txt");
            reservationsFile = Path.Combine(appDataPath, "reservations.txt");
            logFile = Path.Combine(appDataPath, "error.log");
        }

        // ---------- GUESTS ----------
        public List<Guest> LoadGuests()
        {
            List<Guest> guests = new List<Guest>();

            // Java: new File(path).exists()
            if (!File.Exists(guestsFile))
                return guests;

            // Java: a BufferedReader with a while loop.
            // C#: File.ReadAllLines reads the whole file into a string array at once.
            string[] lines = File.ReadAllLines(guestsFile);

            foreach (string line in lines)
            {
                if (string.IsNullOrWhiteSpace(line) || line.StartsWith("#"))
                    continue;

                try
                {
                    guests.Add(Guest.FromFileString(line));
                }
                catch (Exception ex)
                {
                    // One broken line must not crash the whole program.
                    LogError("[Guests] Bad line '" + line + "': " + ex.Message);
                }
            }

            return guests;
        }

        public void SaveGuests(List<Guest> guests)
        {
            List<string> lines = new List<string>();
            lines.Add("# ApartmentBooking - Guests");
            lines.Add("# Format: Id|FirstName|LastName|Email|Phone");

            foreach (Guest g in guests)
                lines.Add(g.ToFileString());

            // Java: FileWriter + BufferedWriter + loop + close().
            // C#: File.WriteAllLines writes everything and closes the file itself.
            File.WriteAllLines(guestsFile, lines);
        }

        // ---------- APARTMENTS ----------
        public List<Apartment> LoadApartments()
        {
            List<Apartment> apartments = new List<Apartment>();
            if (!File.Exists(apartmentsFile))
                return apartments;

            string[] lines = File.ReadAllLines(apartmentsFile);
            foreach (string line in lines)
            {
                if (string.IsNullOrWhiteSpace(line) || line.StartsWith("#"))
                    continue;

                try
                {
                    apartments.Add(Apartment.FromFileString(line));
                }
                catch (Exception ex)
                {
                    LogError("[Apartments] Bad line '" + line + "': " + ex.Message);
                }
            }

            return apartments;
        }

        public void SaveApartments(List<Apartment> apartments)
        {
            List<string> lines = new List<string>();
            lines.Add("# ApartmentBooking - Apartments");
            lines.Add("# Format: Id|Name|Address|PricePerNight|Capacity|IsAvailable|Description");

            foreach (Apartment a in apartments)
                lines.Add(a.ToFileString());

            File.WriteAllLines(apartmentsFile, lines);
        }

        // ---------- RESERVATIONS ----------
        public List<Reservation> LoadReservations()
        {
            List<Reservation> reservations = new List<Reservation>();
            if (!File.Exists(reservationsFile))
                return reservations;

            string[] lines = File.ReadAllLines(reservationsFile);
            foreach (string line in lines)
            {
                if (string.IsNullOrWhiteSpace(line) || line.StartsWith("#"))
                    continue;

                try
                {
                    reservations.Add(Reservation.FromFileString(line));
                }
                catch (Exception ex)
                {
                    LogError("[Reservations] Bad line '" + line + "': " + ex.Message);
                }
            }

            return reservations;
        }

        public void SaveReservations(List<Reservation> reservations)
        {
            List<string> lines = new List<string>();
            lines.Add("# ApartmentBooking - Reservations");
            lines.Add("# Format: Id|GuestId|ApartmentId|CheckIn|CheckOut|Status|TotalPrice|Notes|CreatedAt");

            foreach (Reservation r in reservations)
                lines.Add(r.ToFileString());

            File.WriteAllLines(reservationsFile, lines);
        }

        // ---------- HELPERS ----------
        public string GetDataPath()
        {
            return appDataPath;
        }

        private void LogError(string message)
        {
            try
            {
                // Java: new FileWriter(logFile, true) - the "true" means append.
                File.AppendAllText(logFile, "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] " + message + Environment.NewLine);
            }
            catch
            {
                // If even logging fails we ignore it so the program does not crash.
            }
        }
    }
}
