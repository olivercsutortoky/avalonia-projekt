using System;
using System.Collections.Generic;
using ApartmentBooking.Models;

namespace ApartmentBooking.Services
{
    // The main application logic. The GUI talks ONLY to this class.
    // The GUI never reads files directly and never validates by itself.
    public class BookingService
    {
        private FileService fileService;

        // Data is kept in memory: loaded once at start, saved after every change.
        private List<Guest> guests;
        private List<Apartment> apartments;
        private List<Reservation> reservations;

        public BookingService(FileService fs)
        {
            fileService = fs;
            guests = fileService.LoadGuests();
            apartments = fileService.LoadApartments();
            reservations = fileService.LoadReservations();
        }

        // ================= GUESTS =================
        public List<Guest> GetAllGuests()
        {
            return guests;
        }

        public Guest GetGuestById(int id)
        {
            // Java: for (Guest g : guests) { if (g.getId() == id) return g; }
            foreach (Guest g in guests)
            {
                if (g.Id == id)
                    return g;
            }
            return null;
        }

        public ValidationResult AddGuest(string firstName, string lastName, string email, string phone)
        {
            ValidationResult check = ValidationService.ValidateGuest(firstName, lastName, email, phone);
            if (!check.IsValid)
                return check;

            // The e-mail must be unique.
            foreach (Guest g in guests)
            {
                // Java: g.getEmail().equalsIgnoreCase(email)
                if (string.Equals(g.Email, email.Trim(), StringComparison.OrdinalIgnoreCase))
                    return Fail("Host s timto e-mailem uz existuje.");
            }

            int newId = NextGuestId();
            string safePhone = (phone == null) ? "" : phone.Trim();
            guests.Add(new Guest(newId, firstName.Trim(), lastName.Trim(), email.Trim(), safePhone));
            fileService.SaveGuests(guests);
            return Ok();
        }

        public ValidationResult DeleteGuest(int guestId)
        {
            Guest guest = GetGuestById(guestId);
            if (guest == null)
                return Fail("Host nenalezen.");

            foreach (Reservation r in reservations)
            {
                if (r.GuestId == guestId && r.Status != ReservationStatus.Cancelled && r.CheckOut >= DateTime.Now.Date)
                    return Fail("Nelze smazat hosta s aktivnimi rezervacemi.");
            }

            guests.Remove(guest);
            fileService.SaveGuests(guests);
            return Ok();
        }

        // ================= APARTMENTS =================
        public List<Apartment> GetAllApartments()
        {
            return apartments;
        }

        public Apartment GetApartmentById(int id)
        {
            foreach (Apartment a in apartments)
            {
                if (a.Id == id)
                    return a;
            }
            return null;
        }

        public ValidationResult AddApartment(string name, string address, string priceText, string capacityText, string description)
        {
            ValidationResult check = ValidationService.ValidateApartment(name, address, priceText, capacityText);
            if (!check.IsValid)
                return check;

            int price = int.Parse(priceText.Trim());
            int capacity = int.Parse(capacityText.Trim());
            int newId = NextApartmentId();
            string safeDesc = (description == null) ? "" : description.Trim();

            apartments.Add(new Apartment(newId, name.Trim(), address.Trim(), price, capacity, safeDesc));
            fileService.SaveApartments(apartments);
            return Ok();
        }

        public ValidationResult DeleteApartment(int apartmentId)
        {
            Apartment apt = GetApartmentById(apartmentId);
            if (apt == null)
                return Fail("Apartman nenalezen.");

            foreach (Reservation r in reservations)
            {
                if (r.ApartmentId == apartmentId && r.Status != ReservationStatus.Cancelled && r.CheckOut >= DateTime.Now.Date)
                    return Fail("Nelze smazat apartman s aktivnimi rezervacemi.");
            }

            apartments.Remove(apt);
            fileService.SaveApartments(apartments);
            return Ok();
        }

        // Returns apartments that are free in the given date range.
        public List<Apartment> GetAvailableApartments(DateTime checkIn, DateTime checkOut)
        {
            List<Apartment> result = new List<Apartment>();

            foreach (Apartment a in apartments)
            {
                if (!a.IsAvailable)
                    continue;

                bool hasConflict = false;
                foreach (Reservation r in reservations)
                {
                    if (r.ApartmentId != a.Id)
                        continue;
                    if (r.Status == ReservationStatus.Cancelled)
                        continue;
                    // Two date ranges overlap when one starts before the other ends
                    // and ends after the other starts.
                    if (r.CheckIn < checkOut && r.CheckOut > checkIn)
                    {
                        hasConflict = true;
                        break;
                    }
                }

                if (!hasConflict)
                    result.Add(a);
            }

            return result;
        }

        // ================= RESERVATIONS =================
        public List<Reservation> GetAllReservations()
        {
            return reservations;
        }

        public List<Reservation> GetReservationsForGuest(int guestId)
        {
            List<Reservation> result = new List<Reservation>();
            foreach (Reservation r in reservations)
            {
                if (r.GuestId == guestId)
                    result.Add(r);
            }
            return result;
        }

        public ValidationResult CreateReservation(int guestId, int apartmentId, DateTime checkIn, DateTime checkOut, string notes)
        {
            ValidationResult check = ValidationService.ValidateReservation(guestId, apartmentId, checkIn, checkOut);
            if (!check.IsValid)
                return check;

            if (GetGuestById(guestId) == null)
                return Fail("Host nenalezen.");

            Apartment apt = GetApartmentById(apartmentId);
            if (apt == null)
                return Fail("Apartman nenalezen.");
            if (!apt.IsAvailable)
                return Fail("Apartman je oznacen jako nedostupny.");

            // Conflict check against existing reservations of the same apartment.
            foreach (Reservation r in reservations)
            {
                if (r.ApartmentId != apartmentId)
                    continue;
                if (r.Status == ReservationStatus.Cancelled)
                    continue;
                if (r.CheckIn < checkOut && r.CheckOut > checkIn)
                    return Fail("Apartman je v tomto terminu uz rezervovan.");
            }

            int nights = (int)(checkOut.Date - checkIn.Date).TotalDays;
            int totalPrice = nights * apt.PricePerNight;

            int newId = NextReservationId();
            string safeNotes = (notes == null) ? "" : notes;
            reservations.Add(new Reservation(newId, guestId, apartmentId, checkIn.Date, checkOut.Date, totalPrice, safeNotes));
            fileService.SaveReservations(reservations);
            return Ok();
        }

        public ValidationResult CancelReservation(int reservationId)
        {
            Reservation res = FindReservation(reservationId);
            if (res == null)
                return Fail("Rezervace nenalezena.");
            if (res.Status == ReservationStatus.Cancelled)
                return Fail("Rezervace je uz zrusena.");
            if (res.CheckOut < DateTime.Now.Date)
                return Fail("Nelze zrusit rezervaci, ktera uz probehla.");

            res.Status = ReservationStatus.Cancelled;
            fileService.SaveReservations(reservations);
            return Ok();
        }

        public ValidationResult ConfirmReservation(int reservationId)
        {
            Reservation res = FindReservation(reservationId);
            if (res == null)
                return Fail("Rezervace nenalezena.");
            if (res.Status == ReservationStatus.Cancelled)
                return Fail("Nelze potvrdit zrusenou rezervaci.");
            if (res.Status == ReservationStatus.Confirmed)
                return Fail("Rezervace je uz potvrzena.");

            res.Status = ReservationStatus.Confirmed;
            fileService.SaveReservations(reservations);
            return Ok();
        }

        public string GetDataPath()
        {
            return fileService.GetDataPath();
        }

        // ================= PRIVATE HELPERS =================
        private Reservation FindReservation(int id)
        {
            foreach (Reservation r in reservations)
            {
                if (r.Id == id)
                    return r;
            }
            return null;
        }

        // New id = highest existing id + 1.
        private int NextGuestId()
        {
            int id = 1;
            foreach (Guest g in guests)
                if (g.Id >= id) id = g.Id + 1;
            return id;
        }

        private int NextApartmentId()
        {
            int id = 1;
            foreach (Apartment a in apartments)
                if (a.Id >= id) id = a.Id + 1;
            return id;
        }

        private int NextReservationId()
        {
            int id = 1;
            foreach (Reservation r in reservations)
                if (r.Id >= id) id = r.Id + 1;
            return id;
        }

        private ValidationResult Ok()
        {
            ValidationResult v = new ValidationResult();
            v.IsValid = true;
            return v;
        }

        private ValidationResult Fail(string message)
        {
            ValidationResult v = new ValidationResult();
            v.IsValid = false;
            v.ErrorMessage = message;
            return v;
        }
    }
}
